package com.simplilearn.certProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
